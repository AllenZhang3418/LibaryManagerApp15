# LibaryManagerApp
 This "LibaryManagerApp" is an Android APP source code for a sample libary management system.
